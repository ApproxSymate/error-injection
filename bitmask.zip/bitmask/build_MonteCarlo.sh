gcc -o approx_MonteCarlo  approx_MonteCarlo.c bitflip.c Random.c  -lm -lmpfr
